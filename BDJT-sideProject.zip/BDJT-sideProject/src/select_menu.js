const menuItems = document.querySelectorAll('.nav__menu__item');

    menuItems.forEach(item => {
      item.addEventListener('click', () => {
        // 모든 메뉴 아이템에서 active 클래스 제거
        menuItems.forEach(item => item.classList.remove('active'));

        // 현재 클릭한 메뉴 아이템에 active 클래스 추가
        item.classList.add('active');
      });
    });