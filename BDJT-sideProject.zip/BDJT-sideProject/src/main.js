'use strict';

// Header 섹션을 아래로 스크롤시 투명하게 처리
const header = document.querySelector('.header');
    const scrollThreshold = 50; /* 스크롤 위치가 50px 이상이면 투명 */

    window.addEventListener('scroll', () => {
    if (window.scrollY > scrollThreshold) {
        header.classList.add('transparent');
    } else {
        header.classList.remove('transparent');
    }
});

// Arrow up 버튼을 아래로 스크롤시 투명하게 처리
const homeHeight = home.offsetHeight;
const arrowUp = document.querySelector('.arrow-up');
document.addEventListener('scroll', () => {
    if (window.scrollY >homeHeight / 2) {
        arrowUp.style.opacity = 1;
    }
    else {
        arrowUp.style.opacity = 0;
    }
});

