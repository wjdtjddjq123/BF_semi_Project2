'use strict';
document.addEventListener('DOMContentLoaded', function() {
    const userName = localStorage.getItem('userName');
    new TypeIt('.home__title', {
        speed: 100,
    })
    .pause(1000)
    .move(-7)
    .type('Welcome !<br>')
    .pause(2000)
    .move(null, { to: 'END' })
    .delete(30)
    .type(`${userName}'s ProPlan`)
    .move(8)
    .go();
});