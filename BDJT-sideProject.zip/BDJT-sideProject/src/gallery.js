function clearGallery() {
  localStorage.removeItem('photos');
  loadGallery();
}
function openURL(url) {
  window.open(url, '_blank');
}
function loadGallery(sortByLikes) {
  const gallery = document.getElementById('gallery');
  gallery.innerHTML = '';
  let photos = localStorage.getItem('photos');
  if (!photos) {

    gallery.innerHTML = '<p class="empty-gallery-message">"최고의 프로젝트 게시판의 첫 주인공이 되어보세요!"</p>';
    return;
  }
  photos = JSON.parse(photos);
  photos.forEach((photo, index) => {
    photo.index = index;
  });
  if (sortByLikes) {
    photos.sort((a, b) => (b.likes || 0) - (a.likes || 0)); 
    photos.reverse(); 
  }
  photos.forEach(function (photo, index) {
    const imageContainer = document.createElement('div');
    imageContainer.classList.add('gallery__image-container');
    const img = document.createElement('img');
    img.classList.add('gallery__image');
    img.src = photo.dataURL;
    img.alt = photo.name;
    const title = document.createElement('p');
    title.classList.add('gallery__title');
    title.textContent = photo.title;
    const likes = document.createElement('p');
    likes.className = 'gallery__likes';
    likes.textContent = `${photo.likes || 0} likes`; 
    const likeButton = document.createElement('button');
    likeButton.className = 'gallery__like-button';
    likeButton.innerHTML = '<i class="fa-regular fa-thumbs-up gallery__like-icon"></i>';
    likeButton.setAttribute('data-index', index);
    imageContainer.appendChild(title);
    imageContainer.appendChild(img);
    imageContainer.appendChild(likeButton);
    imageContainer.appendChild(likes);
   
    gallery.appendChild(imageContainer);
    img.addEventListener('click', function () {
      openURL(photo.url);
    });
    likeButton.addEventListener('click', function () {
      if (photos[index]) {
        photos[index].likes = (photos[index].likes || 0) + 1;
        likes.textContent = `${photos[index].likes} likes`;
        localStorage.setItem('photos', JSON.stringify(photos));
      }
    });
  });
}

const sortByLatestButton = document.querySelector('.sortByLatestButton');
const sortByLikesButton = document.querySelector('.sortByLikesButton');
sortByLatestButton.addEventListener('click', function() {
  loadGallery(false); 
});
sortByLikesButton.addEventListener('click', function() {
  loadGallery(true); 
});
loadGallery();