// 브라우저가 localStorage를 지원하는지 확인합니다.
function checkLocalStorageSupport() {
    try {
        return 'localStorage' in window && window['localStorage'] !== null;
    } catch (e) {
        return false;
    }
}

// 사용자 데이터를 localStorage에서 가져오거나 존재하지 않으면 빈 배열로 초기화합니다.
function getUsersFromLocalStorage() {
    const usersData = localStorage.getItem('users');
    return usersData ? JSON.parse(usersData) : [];
}

// 사용자 데이터를 localStorage에 저장합니다.
function saveUsersToLocalStorage(users) {
    localStorage.setItem('users', JSON.stringify(users));
}

// localStorage에서 특정 사용자명을 삭제합니다.
function removeUsernameFromLocalStorage(username) {
const users = JSON.parse(localStorage.getItem('users')) || [];
const updatedUsers = users.filter(user => user.username !== username);
localStorage.setItem('users', JSON.stringify(updatedUsers));
}

// "asdfasdf" 사용자명을 localStorage에서 삭제합니다.
const usernameToDelete = "asdfasdf";
removeUsernameFromLocalStorage(usernameToDelete);

// 로그인 성공 시 호출되는 함수
function onLoginSuccess() {
    // 사용자가 입력한 이름을 가져옴 (여기에서는 예시로 idInput과 nameInput은 각각 아이디와 이름을 입력하는 필드라고 가정)
    const userName = document.getElementById('full-name').value;
  
    // localStorage에 사용자 이름을 저장
    localStorage.setItem('userName', userName);
  }

// 사용자 로그인을 처리합니다.
function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const users = getUsersFromLocalStorage();
    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
        localStorage.setItem('userName', user.username); // user.username이 사용자 이름이라 가정
        alert('로그인 성공!');
        // 메인 페이지로 이동
        window.location.href = "main.html";
    } else {
        alert('아이디 또는 비밀번호가 잘못되었습니다.');
    }
}

// 사용자 회원가입을 처리합니다.
function handleSignup(event) {
    event.preventDefault();
    const newUsername = document.getElementById('new-username').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const users = getUsersFromLocalStorage();
    const userExists = users.some(user => user.username === newUsername);

    // 추가: 비밀번호가 공란인 경우 에러 메시지를 표시하고 함수를 종료합니다.
    if (!newPassword || !confirmPassword) {
        const errorMessage = document.getElementById('error-message');
        errorMessage.innerText = '비밀번호를 입력하세요.';
        errorMessage.style.display = 'block'; // 추가: 에러 메시지를 표시합니다.
        return;
    }
    
    // 비밀번호와 비밀번호 확인이 일치하는지 검사합니다.
    if (newPassword !== confirmPassword) {
        const errorMessage = document.getElementById('error-message');
        errorMessage.innerText = '비밀번호가 일치하지 않습니다.';
        errorMessage.style.display = 'block'; // 추가: 에러 메시지를 표시합니다.
        return;
    }
    
    // 일치할 경우 이전 메시지를 숨깁니다.
    const errorMessage = document.getElementById('password-match-message');
    errorMessage.innerText = '';
    errorMessage.style.display = 'none'; // 추가: 에러 메시지를 숨깁니다.
    
    if (userExists) {
        alert('이미 존재하는 아이디입니다. 다른 아이디를 선택해주세요');
        return;
    }

    const newUser = {
        username: newUsername,
        password: newPassword,
    };
    users.push(newUser);
    saveUsersToLocalStorage(users);
    alert('회원가입이 완료되었습니다!');
    document.getElementById('signup-form').reset();
    showLoginContainer();
}

// Function to handle password change and check if it matches with the confirm password
function handlePasswordChange() {
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const errorMessage = document.getElementById('password-match-message');

    if (!newPassword || !confirmPassword) {
        errorMessage.innerText = '(비밀번호를 입력하세요.)';
        errorMessage.style.display = 'block'; // 추가: 에러 메시지를 표시합니다.
    }
    else if (newPassword !== confirmPassword) {
        errorMessage.textContent = '(비밀번호가 불일치합니다.)';
        errorMessage.style.display = 'block';
    } else {
        errorMessage.textContent = '(비밀번호가 일치합니다!)';
        errorMessage.style.display = 'block';
    }
}

// 회원가입 폼을 보여줍니다.
function showSignupContainer() {
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('signup-container').style.display = 'block';
}

//  로그인 폼을 보여줍니다.
function showLoginContainer() {
    document.getElementById('signup-container').style.display = 'none';
    document.getElementById('login-container').style.display = 'block';
}

// 로그인 및 회원가입 폼에 이벤트 리스너를 추가합니다.
document.getElementById('login-form').addEventListener('submit', handleLogin);
document.getElementById('signup-form').addEventListener('submit', handleSignup);

document.getElementById('new-password').addEventListener('input', handlePasswordChange);
document.getElementById('confirm-password').addEventListener('input', handlePasswordChange);

document.getElementById('signup-button').addEventListener('click', showSignupContainer);
document.getElementById('back-button').addEventListener('click', showLoginContainer);