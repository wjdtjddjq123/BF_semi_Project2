const memoDate = document.querySelector('.selected-date');
const memoInput = document.querySelector('.memo-input');
const memoSaveBtn = document.querySelector('.memo-save');
const memoClearBtn = document.querySelector('.memo-clear');


// 날짜를 렌더링하는 부모 컨테이너를 표시하는
const datesContainer = document.querySelector('.dates');

// 선택한 날짜를 담는 변수
let selectedDate = null;

// 달력 생성 및 날짜 렌더링 함수
function renderCalendar() {
  const date = selectedDate || new Date();
  selectedDate = date;
  const viewYear = date.getFullYear();
  const viewMonth = date.getMonth();
  const today = new Date(); // 오늘 날짜 가져오기

  document.querySelector('.year-month').textContent = `${viewYear} /  ${viewMonth + 1}`;
  const prevLast = new Date(viewYear, viewMonth, 0);
  const thisLast = new Date(viewYear, viewMonth + 1, 0);
  const PLDate = prevLast.getDate();
  const PLDay = prevLast.getDay();
  const TLDate = thisLast.getDate();
  const TLDay = thisLast.getDay();

  const prevDates = [];
  const thisDates = [...Array(TLDate).keys()].slice(1);
  const nextDates = [];

  if (PLDay !== 6) {
    for (let i = 0; i < PLDay; i++) {
      prevDates.unshift(PLDate - i);
    }
  }
   
  for (let i = 1; i < 7 - TLDay; i++) {
    nextDates.push(i);
  }

  const dates = prevDates.concat(thisDates, nextDates);
  datesContainer.innerHTML = dates.map((date) => {
    const isToday = date === today.getDate() && viewMonth === today.getMonth() && viewYear === today.getFullYear();
    return `<div class="date ${isToday ? 'today' : ''}">${date}</div>`;
  }).join('');

  const dateDivs = datesContainer.querySelectorAll('.date');
  dateDivs.forEach((dateDiv) => {
    dateDiv.addEventListener('click', () => {
      handleDateClick(dateDiv);
    });
    showMemoIcon(dateDiv, viewYear, viewMonth);
  });
}
renderCalendar();

// 각 날짜에 메모 아이콘 표시
function showMemoIcon(dateDiv, viewYear, viewMonth) {
  const date = new Date(viewYear, viewMonth, parseInt(dateDiv.textContent));
  date.setHours(0, 0, 0, 0);
  const hasMemo = hasMemoForDate(date);
  if (hasMemo) {
    dateDiv.innerHTML += '<br><span class="memo-icon">📝</span>';
  }
}


// 날짜를 클릭했을 때 처리
function handleDateClick(dateDiv) {
  const viewYear = selectedDate.getFullYear();
  const viewMonth = selectedDate.getMonth();
  const selectedDay = parseInt(dateDiv.textContent, 10);
  selectedDate = new Date(viewYear, viewMonth, selectedDay + 1);
  memoDate.textContent = selectedDate.toISOString().slice(0, 10);
  memoInput.value = getMemo(selectedDate);
  const memoIcon = dateDiv.querySelector('.memo-icon');
  if (memoIcon) {
    memoIcon.addEventListener('click', handleMemoIconClick);
  }
}

// 메모 아이콘을 클릭했을 때 처리
function handleMemoIconClick(event) {
  const dateDiv = event.target.closest('.date');
  const viewYear = selectedDate.getFullYear();
  const viewMonth = selectedDate.getMonth();
  const selectedDay = parseInt(dateDiv.textContent, 10);
  selectedDate = new Date(viewYear, viewMonth, selectedDay);
  const memo = getMemo(selectedDate);
  if (memo.trim() !== '') {
    alert(`메모(${selectedDate.toISOString().slice(0, 10)}):\n\n${memo}`);
  } else {
    alert(`${selectedDate.toISOString().slice(0, 10)}에 저장된 메모가 없습니다.`);
  }
}


// 선택한 날짜에 메모가 있는지 확인
function hasMemoForDate(date) {
  return getMemo(date).trim() !== '';
}

// 선택한 날짜의 메모를 로컬 스토리지에 저장
function saveMemo(date, memo) {
  localStorage.setItem(getMemoKey(date), memo);
}

// 선택한 날짜의 메모를 로컬 스토리지에서 불러오는 함수
function getMemo(date) {
  const memoDateWithoutTime = new Date(date);
  memoDateWithoutTime.setDate(date.getDate() + 1);
  return localStorage.getItem(getMemoKey(memoDateWithoutTime)) || '';
}

// 선택한 날짜의 메모를 삭제
function deleteMemo(date) {
  localStorage.removeItem(getMemoKey(date));
  removeMemoIcon(date);
}

// 선택한 날짜의 메모 아이콘을 삭제
function removeMemoIcon(date) {
  const viewYear = date.getFullYear();
  const viewMonth = date.getMonth();
  const selectedDay = date.getDate();
  const dateDiv = datesContainer.querySelector(`.date:nth-child(${selectedDay})`);
  if (dateDiv) {
    const icon = dateDiv.querySelector('.memo-icon');
    if (icon) {
      icon.remove();
    }
  }
}

// 선택한 날짜의 메모 키를 생성
function getMemoKey(date) {
  return `memo-${date.toISOString().slice(0, 10)}`;
}

// 메모 저장 버튼에 클릭 이벤트 추가
memoSaveBtn.addEventListener('click', () => {
  saveMemo(selectedDate, memoInput.value);
  renderCalendar();
});

// 메모 삭제 버튼에 클릭 이벤트 추가
memoClearBtn.addEventListener('click', () => {
  deleteMemo(selectedDate);
  memoInput.value = '';
  removeMemoIcon(selectedDate);
});

document.querySelector('.go-prev').addEventListener('click', () => {
  const date = new Date(selectedDate);
  date.setMonth(date.getMonth() - 1);
  selectedDate = date;
  renderCalendar();
});

// 다음 달로 이동하는 버튼에 클릭 이벤트 추가
document.querySelector('.go-next').addEventListener('click', () => {
  const date = new Date(selectedDate);
  date.setMonth(date.getMonth() + 1);
  selectedDate = date;
  renderCalendar();
});

// 오늘 날짜로 이동하는 버튼에 클릭 이벤트 추가
document.querySelector('.go-today').addEventListener('click', () => {
  selectedDate = new Date();
  renderCalendar();
});


// 캘린더 불러오기
renderCalendar();