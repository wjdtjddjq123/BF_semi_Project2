document.addEventListener('DOMContentLoaded', function () {
  const fileUploadinput = document.querySelector('.fileUpload__input');

  fileUploadinput.addEventListener('submit', function (event) {
    event.preventDefault();

    const fileInput = document.querySelector('.fileInput');
    const file = fileInput.files[0];
    const titleInput = document.querySelector('.titleInput');
    const title = titleInput.value;
    const urlInput = document.querySelector('.urlInput');
    const url = urlInput.value;

    if (!file || !url || !title) {
      return;
    }

    const reader = new FileReader();

    reader.onload = function () {
      const photo = {
        name: file.name,
        dataURL: reader.result,
        title: title,
        url: url,
      };

      let photos = localStorage.getItem('photos');
      if (photos) {
        photos = JSON.parse(photos);
      } else {
        photos = [];
      }
      
      photos.push(photo);
      localStorage.setItem('photos', JSON.stringify(photos));

      const submitMessage = document.querySelector('.fileUpload__submitMessage');
      submitMessage.style.display = 'block';

      setTimeout(function() {
        submitMessage.style.display = 'none';
      }, 5000);

      fileUploadinput.reset();
    };
    reader.readAsDataURL(file);
  });
});
